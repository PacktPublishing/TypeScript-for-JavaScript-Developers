import validator from "./ZipCodeValidator";

let myValidator = new validator();