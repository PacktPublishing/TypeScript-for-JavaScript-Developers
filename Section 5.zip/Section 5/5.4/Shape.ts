namespace Drawing {
    export interface Shape {
        draw();
    }
}