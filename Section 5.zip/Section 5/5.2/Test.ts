import { StringValidator } from "./Validation";
import { ZipCodeValidator } from "./ZipCodeValidator";

// Some samples to try
let strings = ["Hello", "98052", "101"];

// Validators to use
let validators: {[s: string]: StringValidator} = {};
validators["ZIP Code"] = new ZipCodeValidator();

// Show whether each string passed each validator
strings.forEach(s => {
    for(let name in validators){
        console.log(`"${s}" - ${ validators[name].isAcceptable(s) ?
        "matches" : "does not match"} ${name}`);
    }
});


