define(["require", "exports", "./ZipCodeValidator"], function (require, exports, ZipCodeValidator_1) {
    "use strict";
    exports.__esModule = true;
    // Some samples to try
    var strings = ["Hello", "98052", "101"];
    // Validators to use
    var validators = {};
    validators["ZIP Code"] = new ZipCodeValidator_1.ZipCodeValidator();
    // Show whether each string passed each validator
    strings.forEach(function (s) {
        for (var name_1 in validators) {
            console.log("\"" + s + "\" - " + (validators[name_1].isAcceptable(s) ?
                "matches" : "does not match") + " " + name_1);
        }
    });
});
