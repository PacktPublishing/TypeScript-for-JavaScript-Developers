define(["require", "exports"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
});
