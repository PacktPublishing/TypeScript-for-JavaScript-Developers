// first we defining a new class with constructor
class Author {
    constructor (public Name: string) { }
}

// then we creating the instance of the class
let author = new Author("Anton Selin");
// New we want to see results in console.
console.log("Hello Readers,");
console.log("Thanks for watching this video course");
console.log(`${author.Name}`);