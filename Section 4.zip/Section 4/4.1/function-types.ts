// let myAdd: (x: number, y: number) => number =
//     function (x: number, y: number): number { return x + y; };

let myAdd: (baseValue: number, increment: number) => number =
    function (x: number, y: number): number { return x + y; };